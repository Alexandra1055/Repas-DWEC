/**
 * La Pokedex Digital - Entry Point
 *
 * Importeu les funcions necessaries des de pokedex.js:
 * import { getPokedexEntries, getSelectValues } from './pokedex.js';
 *
 * Recordeu emprar l'estructura MVC amb ES6 modules.
 */
